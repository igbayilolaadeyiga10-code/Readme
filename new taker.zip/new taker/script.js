document.addEventListener('DOMContentLoaded', () => {
    // --- DOM Elements ---
    const signupForm = document.getElementById("signupForm");
    const loginForm = document.getElementById("loginForm");
    const switchBtn = document.getElementById("switchBtn");
    const switchText = document.getElementById("switchText");
    const formTitle = document.getElementById("formTitle");
    const authHeader = document.querySelector('.signup-header');
    const authContainer = document.querySelector('.auth-container');
    const mainContainer = document.querySelector('.main-container');
    const loader = document.getElementById('loader');
    const homePage = document.getElementById('home');
    const container = document.getElementById('page-container');
    const navItems = document.querySelectorAll('.nav-item');
    const buttons = document.querySelectorAll('.action-btn');
    const pages = document.querySelectorAll('.page'); 
    const teamPage = document.getElementById('team');
    const teamContainer = document.getElementById('team-container');


    function hideAllPages() {
  // Hide app pages only
  pages.forEach(page => {
    page.style.display = 'none';
    page.classList.remove('active');
  });

  document.querySelectorAll('.recharge-page').forEach(p => {
    p.style.display = 'none';
  });

  // ❌ DO NOT hide the main container
  // container.style.display = 'none';

  const rechargeHeader = document.querySelector('.recharge-header');
  if (rechargeHeader) rechargeHeader.style.display = 'none';
}



    let isSignup = true;


    document.addEventListener('click', (e) => {
  if (e.target.closest('.logout-btn')) {

    // Clear auth state
    localStorage.removeItem("currentUser");

    // Hide all app pages
    hideAllPages();

    // Hide main app
    mainContainer.style.display = 'none';

    // Hide navbar
    const navbar = document.querySelector('.navbar');
    if (navbar) navbar.style.display = 'none';

    // Show auth
    authContainer.style.display = 'flex';
    authHeader.style.display = 'block';
    const authCard = document.querySelector('.auth-card');
if (authCard) authCard.style.display = 'block';


    // Reset auth UI
    signupForm.classList.remove('active');
    loginForm.classList.add('active');

    formTitle.textContent = "Welcome Back";
    switchText.textContent = "Don’t have an account?";
    switchBtn.textContent = "Sign Up";

    // Reset nav state
    navItems.forEach(nav => nav.classList.remove('active'));

    showPopup("Logged out successfully!", 2000);
  }
});


    // --- Initial State ---
    mainContainer.style.display = 'none';
    authContainer.style.display = 'flex';

    // --- Helpers ---
    async function hashPassword(password) {
        const encoder = new TextEncoder();
        const data = encoder.encode(password);
        const hashBuffer = await crypto.subtle.digest('SHA-256', data);
        return Array.from(new Uint8Array(hashBuffer))
            .map(b => b.toString(16).padStart(2, '0')).join('');
    }

    function showPopup(message, duration = 2500) {
        const popup = document.getElementById('popup');
        popup.textContent = message;
        popup.classList.add('show');
        setTimeout(() => popup.classList.remove('show'), duration);
    }

    async function showLoader(duration = 3000) {
        loader.style.display = 'flex';
        document.body.classList.add('loading');
        return new Promise(resolve => setTimeout(() => {
            loader.style.display = 'none';
            document.body.classList.remove('loading');
            resolve();
        }, duration));
    }
    // --- Form Switching ---
    switchBtn.addEventListener("click", (e) => {
        e.preventDefault();
        isSignup = !isSignup;
        if (isSignup) {
            signupForm.classList.add("active");
            loginForm.classList.remove("active");
            formTitle.textContent = "Create Account";
            switchText.textContent = "Already have an account?";
            switchBtn.textContent = "Login";
        } else {
            signupForm.classList.remove("active");
            loginForm.classList.add("active");
            formTitle.textContent = "Welcome Back";
            switchText.textContent = "Don’t have an account?";
            switchBtn.textContent = "Sign Up";
        }
    });



    // --- Signup ---
    signupForm.addEventListener('submit', async (e) => {
        e.preventDefault();
        const fullName = signupForm[0].value.trim();
        const phone = signupForm[1].value.trim();
        const email = signupForm[2].value.trim();
        const password = signupForm[3].value;
        const confirmPassword = signupForm[4].value;

        if (password !== confirmPassword) return showPopup("Passwords do not match!");

        const hashedPassword = await hashPassword(password);
        let users = JSON.parse(localStorage.getItem('users')  '[]');
        if (users.find(u => u.phone === phone)) return showPopup("Phone number already registered!");

        users.push({ fullName, phone, email, password: hashedPassword });
        localStorage.setItem('users', JSON.stringify(users));

        await showLoader(3000);

        signupForm.classList.remove("active");
        loginForm.classList.add("active");
        formTitle.textContent = "Welcome Back";
        switchText.textContent = "Don’t have an account?";
        switchBtn.textContent = "Sign Up";
        showPopup("Signup successful! Please login to continue.");
    });

    // --- Login ---
    loginForm.addEventListener('submit', async (e) => {
        e.preventDefault();
        const phone = loginForm[0].value.trim();
        const password = loginForm[1].value;
        const hashedPassword = await hashPassword(password);
        const users = JSON.parse(localStorage.getItem('users')  '[]');
        const user = users.find(u => u.phone === phone && u.password === hashedPassword);
        if (!user) return showPopup("Invalid credentials!");

        await showLoader(3000);
        showPopup("Login successful!", 2500);

        // Hide auth and show main
        authContainer.style.display = 'none';
        mainContainer.style.display = 'block';
        authHeader.style.display = 'none';
        document.querySelector('.auth-card').style.display = 'none';

        // Show home page
        hideAllPages();
        homePage.style.display = 'block';
        homePage.classList.add('active');

        // Highlight home nav
        navItems.forEach(nav => nav.classList.remove('active'));
        const homeNav = document.querySelector('.nav-item[data-page="home"]');
        if (homeNav) homeNav.classList.add('active');
    });

    // --- Dynamic button pages ---
    function showButtonPage(pageName) {
        hideAllPages();
        container.style.display = 'block';
        container.innerHTML = `
            <header style="padding:20px; background:#DA00FF; color:#000; border-radius:10px; font-size:24px; text-align:center;">
                ${pageName}
            </header>
            <p style="margin-top:20px; text-align:center;">Content for ${pageName} will go here later.</p>
        `;
        container.scrollIntoView({ behavior: "smooth" });

        navItems.forEach(nav => nav.classList.remove('active'));
    }

    buttons.forEach(btn => {
        btn.addEventListener('click', () => showButtonPage(btn.dataset.page));
    });


    
// ===== ACTION BUTTON PAGE HANDLER =====
document.querySelectorAll('.action-btn').forEach(btn => {
  btn.addEventListener('click', () => {
    const pageId = btn.dataset.page;

    // reset all pages & headers
    hideAllPages();
    // show selected page
    const page = document.getElementById(pageId);
    if (page) {
      page.style.display = 'block';
      page.classList.add('active');
    }

    // show recharge header ONLY for TOPUP
    if (pageId === 'TOPUP') {
      const rechargeHeader = document.querySelector('.recharge-header');
      if (rechargeHeader) rechargeHeader.style.display = 'flex';
    }
  });
});



    // --- Team pages ---
    function showTeamDetail(teamNumber) {
        hideAllPages();
        teamContainer.style.display = 'block';
        teamContainer.innerHTML = `
            <div class="back-arrow" id="back-to-team">← Back</div>
            <h2>Team ${teamNumber}</h2>
            <p>No team yet.</p>
        `;
        document.getElementById('back-to-team').onclick = () => {
            hideAllPages();
            teamPage.style.display = 'block';
            teamPage.classList.add('active');
        };
    }

    teamPage.addEventListener('click', e => {
        if (e.target.classList.contains('view-team-btn')) {
            showTeamDetail(e.target.dataset.team);
        }
    });

    // --- Nav bar clicks ---
    navItems.forEach(item => {
        item.addEventListener('click', async () => {
            if (showLoader) await showLoader(1500);

            navItems.forEach(nav => nav.classList.remove('active'));
            item.classList.add('active');

            const target = item.dataset.page;
            hideAllPages();

            if (target === 'team') {
                teamPage.style.display = 'block';
                teamPage.classList.add('active');
            } else {
                const page = document.getElementById(target);
                if (page) {
                    page.style.display = 'block';
                    page.classList.add('active');
                }
            }
        });
    });

    console.log('TEAM PAGE:', teamPage);
    console.log('TEAM CONTAINER:', teamContainer);
});


function copyText(id) {
  const input = document.getElementById(id);
  input.select();
  input.setSelectionRange(0, 99999);
  navigator.clipboard.writeText(input.value);
  alert("Copied successfully!");
}



let balance = 0;

// Function to update the dashboard balance
function updateDashboard(newBalance) {
  balance = newBalance;
  document.getElementById('userBalance').textContent = `₦${balance.toFixed(2)}`;
}

// Claim button click
document.getElementById('claimBtn').addEventListener('click', function() {
  alert("Claim button clicked!");
  // Later: add logic to increase balance
});

// Example: Update balance dynamically
setTimeout(() => {
  updateDashboard(150.75);
}, 2000);


// Bank page functions
function openBankPage() {
  document.getElementById("bankPage").style.display = "flex";
}

function closeBankPage() {
  document.getElementById("bankPage").style.display = "none";
}

/* make popup globally available */
window.showPopup = function (message, duration = 2500) {
  const popup = document.getElementById("popup");
  if (!popup) return;

  popup.textContent = message;
  popup.classList.add("show");

  setTimeout(() => {
    popup.classList.remove("show");
  }, duration);
};

function saveBank() {
  const inputs = document.querySelectorAll(".bank-form input");

  const bankName = inputs[0]?.value.trim();
  const accountNumber = inputs[1]?.value.trim();
  const accountName = inputs[2]?.value.trim();

  if (!bankName  !accountNumber  !accountName) {
    showPopup("Please fill in all bank details");
    return;
  }

  showPopup("✅ Bank saved successfully");
}


// Deposit history functions
function openDepositHistory() {
  document.getElementById("depositPage").style.display = "flex";
}

function closeDepositHistory() {
  document.getElementById("depositPage").style.display = "none";
}


// Withdrawal history functions
function openWithdrawalHistory() {
  document.getElementById("withdrawalPage").style.display = "flex";
}

function closeWithdrawalHistory() {
  document.getElementById("withdrawalPage").style.display = "none";
}